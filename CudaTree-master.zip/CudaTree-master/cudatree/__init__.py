from random_forest import RandomForestClassifier, convert_result
from datasource import load_data
from util import timer
from random_tree import RandomClassifierTree 
__version__ = "0.6"

